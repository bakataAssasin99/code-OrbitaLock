﻿namespace WindowsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxValidTimes = new System.Windows.Forms.TextBox();
            this.textBoxOpenBolt = new System.Windows.Forms.TextBox();
            this.textBoxAlwaysOpen = new System.Windows.Forms.TextBox();
            this.cBTerminateOld = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxV24 = new System.Windows.Forms.TextBox();
            this.textBoxV16 = new System.Windows.Forms.TextBox();
            this.textBoxV8 = new System.Windows.Forms.TextBox();
            this.textBoxTimeMode = new System.Windows.Forms.TextBox();
            this.textBoxAddressQty = new System.Windows.Forms.TextBox();
            this.DTPSTOut = new System.Windows.Forms.DateTimePicker();
            this.DTPSDOut = new System.Windows.Forms.DateTimePicker();
            this.DTPSTIn = new System.Windows.Forms.DateTimePicker();
            this.DTPSDIn = new System.Windows.Forms.DateTimePicker();
            this.textBoxPassMode = new System.Windows.Forms.TextBox();
            this.textBoxLevelPass = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxAddressMode = new System.Windows.Forms.TextBox();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.textBoxPass = new System.Windows.Forms.TextBox();
            this.textBoxHotelCode = new System.Windows.Forms.TextBox();
            this.textBoxSystemCode = new System.Windows.Forms.TextBox();
            this.textBoxCardPass = new System.Windows.Forms.TextBox();
            this.textBoxEncrypt = new System.Windows.Forms.TextBox();
            this.textBoxnBlock = new System.Windows.Forms.TextBox();
            this.textBoxGuestCard = new System.Windows.Forms.TextBox();
            this.textBoxCom = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textBoxValidTimes);
            this.groupBox1.Controls.Add(this.textBoxOpenBolt);
            this.groupBox1.Controls.Add(this.textBoxAlwaysOpen);
            this.groupBox1.Controls.Add(this.cBTerminateOld);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.textBoxV24);
            this.groupBox1.Controls.Add(this.textBoxV16);
            this.groupBox1.Controls.Add(this.textBoxV8);
            this.groupBox1.Controls.Add(this.textBoxTimeMode);
            this.groupBox1.Controls.Add(this.textBoxAddressQty);
            this.groupBox1.Controls.Add(this.DTPSTOut);
            this.groupBox1.Controls.Add(this.DTPSDOut);
            this.groupBox1.Controls.Add(this.DTPSTIn);
            this.groupBox1.Controls.Add(this.DTPSDIn);
            this.groupBox1.Controls.Add(this.textBoxPassMode);
            this.groupBox1.Controls.Add(this.textBoxLevelPass);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBoxAddressMode);
            this.groupBox1.Controls.Add(this.textBoxAddress);
            this.groupBox1.Controls.Add(this.textBoxPass);
            this.groupBox1.Controls.Add(this.textBoxHotelCode);
            this.groupBox1.Controls.Add(this.textBoxSystemCode);
            this.groupBox1.Controls.Add(this.textBoxCardPass);
            this.groupBox1.Controls.Add(this.textBoxEncrypt);
            this.groupBox1.Controls.Add(this.textBoxnBlock);
            this.groupBox1.Controls.Add(this.textBoxGuestCard);
            this.groupBox1.Controls.Add(this.textBoxCom);
            this.groupBox1.Location = new System.Drawing.Point(14, 9);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(1107, 400);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(406, 318);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(206, 53);
            this.button2.TabIndex = 50;
            this.button2.Text = "Read Card";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(188, 318);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(206, 53);
            this.button1.TabIndex = 49;
            this.button1.Text = "Write Card";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxValidTimes
            // 
            this.textBoxValidTimes.Location = new System.Drawing.Point(982, 338);
            this.textBoxValidTimes.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxValidTimes.Name = "textBoxValidTimes";
            this.textBoxValidTimes.Size = new System.Drawing.Size(112, 26);
            this.textBoxValidTimes.TabIndex = 48;
            this.textBoxValidTimes.Text = "255";
            // 
            // textBoxOpenBolt
            // 
            this.textBoxOpenBolt.Location = new System.Drawing.Point(982, 261);
            this.textBoxOpenBolt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxOpenBolt.Name = "textBoxOpenBolt";
            this.textBoxOpenBolt.Size = new System.Drawing.Size(124, 26);
            this.textBoxOpenBolt.TabIndex = 47;
            this.textBoxOpenBolt.Text = "0";
            // 
            // textBoxAlwaysOpen
            // 
            this.textBoxAlwaysOpen.Location = new System.Drawing.Point(982, 218);
            this.textBoxAlwaysOpen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxAlwaysOpen.Name = "textBoxAlwaysOpen";
            this.textBoxAlwaysOpen.Size = new System.Drawing.Size(124, 26);
            this.textBoxAlwaysOpen.TabIndex = 46;
            this.textBoxAlwaysOpen.Text = "0";
            // 
            // cBTerminateOld
            // 
            this.cBTerminateOld.AutoSize = true;
            this.cBTerminateOld.Checked = true;
            this.cBTerminateOld.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cBTerminateOld.Location = new System.Drawing.Point(867, 302);
            this.cBTerminateOld.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cBTerminateOld.Name = "cBTerminateOld";
            this.cBTerminateOld.Size = new System.Drawing.Size(130, 24);
            this.cBTerminateOld.TabIndex = 45;
            this.cBTerminateOld.Text = "TerminateOld";
            this.cBTerminateOld.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(867, 343);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(86, 20);
            this.label24.TabIndex = 44;
            this.label24.Text = "ValidTimes";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(867, 264);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(76, 20);
            this.label23.TabIndex = 43;
            this.label23.Text = "OpenBolt";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(867, 221);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(97, 20);
            this.label22.TabIndex = 42;
            this.label22.Text = "AlwaysOpen";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(1017, 174);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 20);
            this.label21.TabIndex = 41;
            this.label21.Text = "V24";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(940, 174);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(38, 20);
            this.label20.TabIndex = 40;
            this.label20.Text = "V16";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(867, 174);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 20);
            this.label19.TabIndex = 39;
            this.label19.Text = "V8";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(867, 127);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 20);
            this.label18.TabIndex = 38;
            this.label18.Text = "TimeMode";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(867, 80);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(92, 20);
            this.label17.TabIndex = 37;
            this.label17.Text = "AddressQty";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(867, 33);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(108, 20);
            this.label16.TabIndex = 36;
            this.label16.Text = "AddressMode";
            // 
            // textBoxV24
            // 
            this.textBoxV24.Location = new System.Drawing.Point(1056, 171);
            this.textBoxV24.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxV24.Name = "textBoxV24";
            this.textBoxV24.Size = new System.Drawing.Size(42, 26);
            this.textBoxV24.TabIndex = 35;
            this.textBoxV24.Text = "255";
            // 
            // textBoxV16
            // 
            this.textBoxV16.Location = new System.Drawing.Point(975, 171);
            this.textBoxV16.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxV16.Name = "textBoxV16";
            this.textBoxV16.Size = new System.Drawing.Size(42, 26);
            this.textBoxV16.TabIndex = 34;
            this.textBoxV16.Text = "255";
            // 
            // textBoxV8
            // 
            this.textBoxV8.Location = new System.Drawing.Point(894, 171);
            this.textBoxV8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxV8.Name = "textBoxV8";
            this.textBoxV8.Size = new System.Drawing.Size(42, 26);
            this.textBoxV8.TabIndex = 33;
            this.textBoxV8.Text = "255";
            // 
            // textBoxTimeMode
            // 
            this.textBoxTimeMode.Location = new System.Drawing.Point(982, 124);
            this.textBoxTimeMode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTimeMode.Name = "textBoxTimeMode";
            this.textBoxTimeMode.Size = new System.Drawing.Size(112, 26);
            this.textBoxTimeMode.TabIndex = 32;
            this.textBoxTimeMode.Text = "0";
            // 
            // textBoxAddressQty
            // 
            this.textBoxAddressQty.Location = new System.Drawing.Point(982, 77);
            this.textBoxAddressQty.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxAddressQty.Name = "textBoxAddressQty";
            this.textBoxAddressQty.Size = new System.Drawing.Size(112, 26);
            this.textBoxAddressQty.TabIndex = 31;
            this.textBoxAddressQty.Text = "1";
            // 
            // DTPSTOut
            // 
            this.DTPSTOut.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DTPSTOut.Location = new System.Drawing.Point(669, 171);
            this.DTPSTOut.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.DTPSTOut.Name = "DTPSTOut";
            this.DTPSTOut.ShowUpDown = true;
            this.DTPSTOut.Size = new System.Drawing.Size(136, 26);
            this.DTPSTOut.TabIndex = 30;
            // 
            // DTPSDOut
            // 
            this.DTPSDOut.CustomFormat = "yy-MM-dd";
            this.DTPSDOut.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTPSDOut.Location = new System.Drawing.Point(669, 124);
            this.DTPSDOut.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.DTPSDOut.Name = "DTPSDOut";
            this.DTPSDOut.Size = new System.Drawing.Size(136, 26);
            this.DTPSDOut.TabIndex = 29;
            // 
            // DTPSTIn
            // 
            this.DTPSTIn.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DTPSTIn.Location = new System.Drawing.Point(669, 77);
            this.DTPSTIn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.DTPSTIn.Name = "DTPSTIn";
            this.DTPSTIn.ShowUpDown = true;
            this.DTPSTIn.Size = new System.Drawing.Size(136, 26);
            this.DTPSTIn.TabIndex = 28;
            // 
            // DTPSDIn
            // 
            this.DTPSDIn.CustomFormat = "yy-MM-dd";
            this.DTPSDIn.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTPSDIn.Location = new System.Drawing.Point(669, 30);
            this.DTPSDIn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.DTPSDIn.Name = "DTPSDIn";
            this.DTPSDIn.Size = new System.Drawing.Size(139, 26);
            this.DTPSDIn.TabIndex = 27;
            // 
            // textBoxPassMode
            // 
            this.textBoxPassMode.Location = new System.Drawing.Point(669, 261);
            this.textBoxPassMode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxPassMode.Name = "textBoxPassMode";
            this.textBoxPassMode.Size = new System.Drawing.Size(136, 26);
            this.textBoxPassMode.TabIndex = 26;
            this.textBoxPassMode.Text = "1";
            // 
            // textBoxLevelPass
            // 
            this.textBoxLevelPass.Location = new System.Drawing.Point(669, 218);
            this.textBoxLevelPass.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxLevelPass.Name = "textBoxLevelPass";
            this.textBoxLevelPass.Size = new System.Drawing.Size(136, 26);
            this.textBoxLevelPass.TabIndex = 25;
            this.textBoxLevelPass.Text = "3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(579, 264);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 20);
            this.label15.TabIndex = 24;
            this.label15.Text = "PassMode";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(579, 221);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 20);
            this.label14.TabIndex = 23;
            this.label14.Text = "LevelPass";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(579, 174);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 20);
            this.label13.TabIndex = 22;
            this.label13.Text = "STOUT";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(579, 127);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 20);
            this.label12.TabIndex = 21;
            this.label12.Text = "SDOUT";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(579, 80);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 20);
            this.label11.TabIndex = 20;
            this.label11.Text = "STIN";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(579, 33);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 20);
            this.label10.TabIndex = 19;
            this.label10.Text = "SDIN";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(298, 174);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "RoomAddress";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(298, 127);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 20);
            this.label8.TabIndex = 17;
            this.label8.Text = "RoomPass";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(298, 80);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "HotelCode";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(298, 33);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "SystemCode";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 221);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "CardPass";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 174);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Encrypt";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 127);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "nBlock";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 80);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "CardNumber";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "ComNumber";
            // 
            // textBoxAddressMode
            // 
            this.textBoxAddressMode.Location = new System.Drawing.Point(982, 30);
            this.textBoxAddressMode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxAddressMode.Name = "textBoxAddressMode";
            this.textBoxAddressMode.Size = new System.Drawing.Size(112, 26);
            this.textBoxAddressMode.TabIndex = 9;
            this.textBoxAddressMode.Text = "0";
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Location = new System.Drawing.Point(415, 171);
            this.textBoxAddress.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(115, 26);
            this.textBoxAddress.TabIndex = 8;
            this.textBoxAddress.Text = "01010200700";
            // 
            // textBoxPass
            // 
            this.textBoxPass.Location = new System.Drawing.Point(415, 124);
            this.textBoxPass.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxPass.Name = "textBoxPass";
            this.textBoxPass.Size = new System.Drawing.Size(115, 26);
            this.textBoxPass.TabIndex = 7;
            this.textBoxPass.Text = "111222";
            // 
            // textBoxHotelCode
            // 
            this.textBoxHotelCode.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBoxHotelCode.Location = new System.Drawing.Point(415, 77);
            this.textBoxHotelCode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxHotelCode.Name = "textBoxHotelCode";
            this.textBoxHotelCode.Size = new System.Drawing.Size(115, 26);
            this.textBoxHotelCode.TabIndex = 6;
            this.textBoxHotelCode.Text = "A970F956";
            // 
            // textBoxSystemCode
            // 
            this.textBoxSystemCode.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBoxSystemCode.Location = new System.Drawing.Point(415, 30);
            this.textBoxSystemCode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSystemCode.Name = "textBoxSystemCode";
            this.textBoxSystemCode.Size = new System.Drawing.Size(115, 26);
            this.textBoxSystemCode.TabIndex = 5;
            this.textBoxSystemCode.Text = "EF0C5E05";
            // 
            // textBoxCardPass
            // 
            this.textBoxCardPass.Location = new System.Drawing.Point(113, 218);
            this.textBoxCardPass.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxCardPass.Name = "textBoxCardPass";
            this.textBoxCardPass.Size = new System.Drawing.Size(127, 26);
            this.textBoxCardPass.TabIndex = 4;
            this.textBoxCardPass.Text = "33AA9C2693F8";
            // 
            // textBoxEncrypt
            // 
            this.textBoxEncrypt.Location = new System.Drawing.Point(113, 171);
            this.textBoxEncrypt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxEncrypt.Name = "textBoxEncrypt";
            this.textBoxEncrypt.Size = new System.Drawing.Size(127, 26);
            this.textBoxEncrypt.TabIndex = 3;
            this.textBoxEncrypt.Text = "88";
            // 
            // textBoxnBlock
            // 
            this.textBoxnBlock.Location = new System.Drawing.Point(113, 124);
            this.textBoxnBlock.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxnBlock.Name = "textBoxnBlock";
            this.textBoxnBlock.Size = new System.Drawing.Size(127, 26);
            this.textBoxnBlock.TabIndex = 2;
            this.textBoxnBlock.Text = "8";
            // 
            // textBoxGuestCard
            // 
            this.textBoxGuestCard.Location = new System.Drawing.Point(113, 77);
            this.textBoxGuestCard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxGuestCard.Name = "textBoxGuestCard";
            this.textBoxGuestCard.Size = new System.Drawing.Size(127, 26);
            this.textBoxGuestCard.TabIndex = 1;
            this.textBoxGuestCard.Text = "123";
            // 
            // textBoxCom
            // 
            this.textBoxCom.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBoxCom.Location = new System.Drawing.Point(113, 30);
            this.textBoxCom.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxCom.Name = "textBoxCom";
            this.textBoxCom.Size = new System.Drawing.Size(127, 26);
            this.textBoxCom.TabIndex = 0;
            this.textBoxCom.Text = "1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1134, 418);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Guest Card C# Demo-V30";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxValidTimes;
        private System.Windows.Forms.TextBox textBoxOpenBolt;
        private System.Windows.Forms.TextBox textBoxAlwaysOpen;
        private System.Windows.Forms.CheckBox cBTerminateOld;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxV24;
        private System.Windows.Forms.TextBox textBoxV16;
        private System.Windows.Forms.TextBox textBoxV8;
        private System.Windows.Forms.TextBox textBoxTimeMode;
        private System.Windows.Forms.TextBox textBoxAddressQty;
        private System.Windows.Forms.DateTimePicker DTPSTOut;
        private System.Windows.Forms.DateTimePicker DTPSDOut;
        private System.Windows.Forms.DateTimePicker DTPSTIn;
        private System.Windows.Forms.DateTimePicker DTPSDIn;
        private System.Windows.Forms.TextBox textBoxPassMode;
        private System.Windows.Forms.TextBox textBoxLevelPass;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxAddressMode;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.TextBox textBoxPass;
        private System.Windows.Forms.TextBox textBoxHotelCode;
        private System.Windows.Forms.TextBox textBoxSystemCode;
        private System.Windows.Forms.TextBox textBoxCardPass;
        private System.Windows.Forms.TextBox textBoxEncrypt;
        private System.Windows.Forms.TextBox textBoxnBlock;
        private System.Windows.Forms.TextBox textBoxGuestCard;
        private System.Windows.Forms.TextBox textBoxCom;
    }
}

