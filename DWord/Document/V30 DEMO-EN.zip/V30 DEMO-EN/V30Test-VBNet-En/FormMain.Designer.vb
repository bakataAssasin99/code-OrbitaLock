<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class FormMain
#Region "Windows ������������ɵĴ��� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�˵����� Windows ���������������ġ�
		InitializeComponent()
	End Sub
	'������д�ͷţ�����������б���
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows ����������������
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Command1 As System.Windows.Forms.Button
    Public WithEvents Com_GuestCard As System.Windows.Forms.Button
    Public WithEvents T_ValidTimes As System.Windows.Forms.TextBox
	Public WithEvents Check_TerminateOld As System.Windows.Forms.CheckBox
	Public WithEvents T_V16 As System.Windows.Forms.TextBox
    Public WithEvents T_OpenBolt As System.Windows.Forms.TextBox
    Public WithEvents T_V8 As System.Windows.Forms.TextBox
	Public WithEvents T_V24 As System.Windows.Forms.TextBox
	Public WithEvents T_STIN As System.Windows.Forms.TextBox
	Public WithEvents T_SDIN As System.Windows.Forms.TextBox
	Public WithEvents T_PassMode As System.Windows.Forms.TextBox
	Public WithEvents T_TimeMode As System.Windows.Forms.TextBox
	Public WithEvents T_AddressQty As System.Windows.Forms.TextBox
	Public WithEvents T_LevelPass As System.Windows.Forms.TextBox
	Public WithEvents T_AddressMode As System.Windows.Forms.TextBox
	Public WithEvents T_STOUT As System.Windows.Forms.TextBox
	Public WithEvents T_SDOUT As System.Windows.Forms.TextBox
	Public WithEvents T_Address As System.Windows.Forms.TextBox
	Public WithEvents T_CardNo As System.Windows.Forms.TextBox
	Public WithEvents T_Com As System.Windows.Forms.TextBox
	Public WithEvents T_Encrypt As System.Windows.Forms.TextBox
	Public WithEvents T_nBlock As System.Windows.Forms.TextBox
	Public WithEvents T_SystemCode As System.Windows.Forms.TextBox
	Public WithEvents T_HotelCode As System.Windows.Forms.TextBox
	Public WithEvents T_CardPass As System.Windows.Forms.TextBox
	Public WithEvents T_Pass As System.Windows.Forms.TextBox
	Public WithEvents Com_ReadMessage As System.Windows.Forms.Button
	Public WithEvents Label19 As System.Windows.Forms.Label
	Public WithEvents Label18 As System.Windows.Forms.Label
	Public WithEvents Label15 As System.Windows.Forms.Label
	Public WithEvents Label13 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Card_no_ As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents comport_lbl As System.Windows.Forms.Label
	Public WithEvents Label17 As System.Windows.Forms.Label
	Public WithEvents Label16 As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Door_no_lbl As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents O_PASSSS As System.Windows.Forms.Label
	Public WithEvents room_address As System.Windows.Forms.Label
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Label14 As System.Windows.Forms.Label
	'ע��: ���¹����� Windows ����������������
	'����ʹ�� Windows ������������޸�����
	'��Ҫʹ�ô���༭���޸�����
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Command1 = New System.Windows.Forms.Button()
        Me.Com_GuestCard = New System.Windows.Forms.Button()
        Me.T_ValidTimes = New System.Windows.Forms.TextBox()
        Me.Check_TerminateOld = New System.Windows.Forms.CheckBox()
        Me.T_V16 = New System.Windows.Forms.TextBox()
        Me.T_OpenBolt = New System.Windows.Forms.TextBox()
        Me.T_V8 = New System.Windows.Forms.TextBox()
        Me.T_V24 = New System.Windows.Forms.TextBox()
        Me.T_STIN = New System.Windows.Forms.TextBox()
        Me.T_SDIN = New System.Windows.Forms.TextBox()
        Me.T_PassMode = New System.Windows.Forms.TextBox()
        Me.T_TimeMode = New System.Windows.Forms.TextBox()
        Me.T_AddressQty = New System.Windows.Forms.TextBox()
        Me.T_LevelPass = New System.Windows.Forms.TextBox()
        Me.T_AddressMode = New System.Windows.Forms.TextBox()
        Me.T_STOUT = New System.Windows.Forms.TextBox()
        Me.T_SDOUT = New System.Windows.Forms.TextBox()
        Me.T_Address = New System.Windows.Forms.TextBox()
        Me.T_CardNo = New System.Windows.Forms.TextBox()
        Me.T_Com = New System.Windows.Forms.TextBox()
        Me.T_Encrypt = New System.Windows.Forms.TextBox()
        Me.T_nBlock = New System.Windows.Forms.TextBox()
        Me.T_SystemCode = New System.Windows.Forms.TextBox()
        Me.T_HotelCode = New System.Windows.Forms.TextBox()
        Me.T_CardPass = New System.Windows.Forms.TextBox()
        Me.T_Pass = New System.Windows.Forms.TextBox()
        Me.Com_ReadMessage = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Card_no_ = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.comport_lbl = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Door_no_lbl = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.O_PASSSS = New System.Windows.Forms.Label()
        Me.room_address = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.T_AlwaysOpen = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.SystemColors.Control
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Location = New System.Drawing.Point(551, 268)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(105, 62)
        Me.Command1.TabIndex = 52
        Me.Command1.Text = "Close"
        Me.Command1.UseVisualStyleBackColor = False
        '
        'Com_GuestCard
        '
        Me.Com_GuestCard.BackColor = System.Drawing.SystemColors.Control
        Me.Com_GuestCard.Cursor = System.Windows.Forms.Cursors.Default
        Me.Com_GuestCard.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Com_GuestCard.Location = New System.Drawing.Point(121, 268)
        Me.Com_GuestCard.Name = "Com_GuestCard"
        Me.Com_GuestCard.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Com_GuestCard.Size = New System.Drawing.Size(126, 62)
        Me.Com_GuestCard.TabIndex = 50
        Me.Com_GuestCard.Text = "Write Card"
        Me.Com_GuestCard.UseVisualStyleBackColor = False
        '
        'T_ValidTimes
        '
        Me.T_ValidTimes.AcceptsReturn = True
        Me.T_ValidTimes.BackColor = System.Drawing.SystemColors.Window
        Me.T_ValidTimes.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_ValidTimes.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_ValidTimes.Location = New System.Drawing.Point(963, 294)
        Me.T_ValidTimes.MaxLength = 0
        Me.T_ValidTimes.Name = "T_ValidTimes"
        Me.T_ValidTimes.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_ValidTimes.Size = New System.Drawing.Size(49, 26)
        Me.T_ValidTimes.TabIndex = 49
        Me.T_ValidTimes.Text = "255"
        '
        'Check_TerminateOld
        '
        Me.Check_TerminateOld.BackColor = System.Drawing.SystemColors.Control
        Me.Check_TerminateOld.Cursor = System.Windows.Forms.Cursors.Default
        Me.Check_TerminateOld.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Check_TerminateOld.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Check_TerminateOld.Location = New System.Drawing.Point(859, 254)
        Me.Check_TerminateOld.Name = "Check_TerminateOld"
        Me.Check_TerminateOld.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Check_TerminateOld.Size = New System.Drawing.Size(169, 25)
        Me.Check_TerminateOld.TabIndex = 47
        Me.Check_TerminateOld.Text = "TerminateOld"
        Me.Check_TerminateOld.UseVisualStyleBackColor = False
        '
        'T_V16
        '
        Me.T_V16.AcceptsReturn = True
        Me.T_V16.BackColor = System.Drawing.SystemColors.Window
        Me.T_V16.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_V16.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_V16.Location = New System.Drawing.Point(991, 140)
        Me.T_V16.MaxLength = 0
        Me.T_V16.Name = "T_V16"
        Me.T_V16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_V16.Size = New System.Drawing.Size(41, 26)
        Me.T_V16.TabIndex = 46
        Me.T_V16.Text = "255"
        '
        'T_OpenBolt
        '
        Me.T_OpenBolt.AcceptsReturn = True
        Me.T_OpenBolt.BackColor = System.Drawing.SystemColors.Window
        Me.T_OpenBolt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_OpenBolt.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_OpenBolt.Location = New System.Drawing.Point(978, 215)
        Me.T_OpenBolt.MaxLength = 0
        Me.T_OpenBolt.Name = "T_OpenBolt"
        Me.T_OpenBolt.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_OpenBolt.Size = New System.Drawing.Size(139, 26)
        Me.T_OpenBolt.TabIndex = 45
        Me.T_OpenBolt.Text = "0"
        '
        'T_V8
        '
        Me.T_V8.AcceptsReturn = True
        Me.T_V8.BackColor = System.Drawing.SystemColors.Window
        Me.T_V8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_V8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_V8.Location = New System.Drawing.Point(890, 140)
        Me.T_V8.MaxLength = 0
        Me.T_V8.Name = "T_V8"
        Me.T_V8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_V8.Size = New System.Drawing.Size(39, 26)
        Me.T_V8.TabIndex = 43
        Me.T_V8.Text = "255"
        '
        'T_V24
        '
        Me.T_V24.AcceptsReturn = True
        Me.T_V24.BackColor = System.Drawing.SystemColors.Window
        Me.T_V24.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_V24.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_V24.Location = New System.Drawing.Point(1081, 140)
        Me.T_V24.MaxLength = 0
        Me.T_V24.Name = "T_V24"
        Me.T_V24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_V24.Size = New System.Drawing.Size(37, 26)
        Me.T_V24.TabIndex = 42
        Me.T_V24.Text = "255"
        '
        'T_STIN
        '
        Me.T_STIN.AcceptsReturn = True
        Me.T_STIN.BackColor = System.Drawing.SystemColors.Window
        Me.T_STIN.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_STIN.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_STIN.Location = New System.Drawing.Point(681, 60)
        Me.T_STIN.MaxLength = 0
        Me.T_STIN.Name = "T_STIN"
        Me.T_STIN.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_STIN.Size = New System.Drawing.Size(128, 26)
        Me.T_STIN.TabIndex = 36
        Me.T_STIN.Text = "14:12:13"
        '
        'T_SDIN
        '
        Me.T_SDIN.AcceptsReturn = True
        Me.T_SDIN.BackColor = System.Drawing.SystemColors.Window
        Me.T_SDIN.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_SDIN.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_SDIN.Location = New System.Drawing.Point(681, 20)
        Me.T_SDIN.MaxLength = 0
        Me.T_SDIN.Name = "T_SDIN"
        Me.T_SDIN.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_SDIN.Size = New System.Drawing.Size(128, 26)
        Me.T_SDIN.TabIndex = 35
        Me.T_SDIN.Text = "09-09-10"
        '
        'T_PassMode
        '
        Me.T_PassMode.AcceptsReturn = True
        Me.T_PassMode.BackColor = System.Drawing.SystemColors.Window
        Me.T_PassMode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_PassMode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_PassMode.Location = New System.Drawing.Point(681, 215)
        Me.T_PassMode.MaxLength = 0
        Me.T_PassMode.Name = "T_PassMode"
        Me.T_PassMode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_PassMode.Size = New System.Drawing.Size(128, 26)
        Me.T_PassMode.TabIndex = 34
        Me.T_PassMode.Text = "1"
        '
        'T_TimeMode
        '
        Me.T_TimeMode.AcceptsReturn = True
        Me.T_TimeMode.BackColor = System.Drawing.SystemColors.Window
        Me.T_TimeMode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_TimeMode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_TimeMode.Location = New System.Drawing.Point(978, 100)
        Me.T_TimeMode.MaxLength = 0
        Me.T_TimeMode.Name = "T_TimeMode"
        Me.T_TimeMode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_TimeMode.Size = New System.Drawing.Size(139, 26)
        Me.T_TimeMode.TabIndex = 33
        Me.T_TimeMode.Text = "0"
        '
        'T_AddressQty
        '
        Me.T_AddressQty.AcceptsReturn = True
        Me.T_AddressQty.BackColor = System.Drawing.SystemColors.Window
        Me.T_AddressQty.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_AddressQty.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_AddressQty.Location = New System.Drawing.Point(978, 60)
        Me.T_AddressQty.MaxLength = 0
        Me.T_AddressQty.Name = "T_AddressQty"
        Me.T_AddressQty.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_AddressQty.Size = New System.Drawing.Size(139, 26)
        Me.T_AddressQty.TabIndex = 32
        Me.T_AddressQty.Text = "1"
        '
        'T_LevelPass
        '
        Me.T_LevelPass.AcceptsReturn = True
        Me.T_LevelPass.BackColor = System.Drawing.SystemColors.Window
        Me.T_LevelPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_LevelPass.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_LevelPass.Location = New System.Drawing.Point(681, 180)
        Me.T_LevelPass.MaxLength = 0
        Me.T_LevelPass.Name = "T_LevelPass"
        Me.T_LevelPass.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_LevelPass.Size = New System.Drawing.Size(128, 26)
        Me.T_LevelPass.TabIndex = 31
        Me.T_LevelPass.Text = "3"
        '
        'T_AddressMode
        '
        Me.T_AddressMode.AcceptsReturn = True
        Me.T_AddressMode.BackColor = System.Drawing.SystemColors.Window
        Me.T_AddressMode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_AddressMode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_AddressMode.Location = New System.Drawing.Point(978, 20)
        Me.T_AddressMode.MaxLength = 0
        Me.T_AddressMode.Name = "T_AddressMode"
        Me.T_AddressMode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_AddressMode.Size = New System.Drawing.Size(139, 26)
        Me.T_AddressMode.TabIndex = 30
        Me.T_AddressMode.Text = "0"
        '
        'T_STOUT
        '
        Me.T_STOUT.AcceptsReturn = True
        Me.T_STOUT.BackColor = System.Drawing.SystemColors.Window
        Me.T_STOUT.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_STOUT.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_STOUT.Location = New System.Drawing.Point(681, 140)
        Me.T_STOUT.MaxLength = 0
        Me.T_STOUT.Name = "T_STOUT"
        Me.T_STOUT.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_STOUT.Size = New System.Drawing.Size(128, 26)
        Me.T_STOUT.TabIndex = 29
        Me.T_STOUT.Text = "15:12:20"
        '
        'T_SDOUT
        '
        Me.T_SDOUT.AcceptsReturn = True
        Me.T_SDOUT.BackColor = System.Drawing.SystemColors.Window
        Me.T_SDOUT.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_SDOUT.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_SDOUT.Location = New System.Drawing.Point(681, 100)
        Me.T_SDOUT.MaxLength = 0
        Me.T_SDOUT.Name = "T_SDOUT"
        Me.T_SDOUT.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_SDOUT.Size = New System.Drawing.Size(128, 26)
        Me.T_SDOUT.TabIndex = 28
        Me.T_SDOUT.Text = "19-12-10"
        '
        'T_Address
        '
        Me.T_Address.AcceptsReturn = True
        Me.T_Address.BackColor = System.Drawing.SystemColors.Window
        Me.T_Address.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_Address.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_Address.Location = New System.Drawing.Point(415, 140)
        Me.T_Address.MaxLength = 0
        Me.T_Address.Name = "T_Address"
        Me.T_Address.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_Address.Size = New System.Drawing.Size(128, 26)
        Me.T_Address.TabIndex = 27
        Me.T_Address.Text = "01010100100"
        '
        'T_CardNo
        '
        Me.T_CardNo.AcceptsReturn = True
        Me.T_CardNo.BackColor = System.Drawing.SystemColors.Window
        Me.T_CardNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_CardNo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_CardNo.Location = New System.Drawing.Point(130, 60)
        Me.T_CardNo.MaxLength = 0
        Me.T_CardNo.Name = "T_CardNo"
        Me.T_CardNo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_CardNo.Size = New System.Drawing.Size(128, 26)
        Me.T_CardNo.TabIndex = 24
        Me.T_CardNo.Text = "555"
        '
        'T_Com
        '
        Me.T_Com.AcceptsReturn = True
        Me.T_Com.BackColor = System.Drawing.SystemColors.Window
        Me.T_Com.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_Com.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.T_Com.Location = New System.Drawing.Point(130, 20)
        Me.T_Com.MaxLength = 0
        Me.T_Com.Name = "T_Com"
        Me.T_Com.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_Com.Size = New System.Drawing.Size(128, 26)
        Me.T_Com.TabIndex = 21
        Me.T_Com.Text = "2"
        '
        'T_Encrypt
        '
        Me.T_Encrypt.AcceptsReturn = True
        Me.T_Encrypt.BackColor = System.Drawing.SystemColors.Window
        Me.T_Encrypt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_Encrypt.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_Encrypt.Location = New System.Drawing.Point(130, 140)
        Me.T_Encrypt.MaxLength = 0
        Me.T_Encrypt.Name = "T_Encrypt"
        Me.T_Encrypt.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_Encrypt.Size = New System.Drawing.Size(128, 26)
        Me.T_Encrypt.TabIndex = 17
        Me.T_Encrypt.Text = "88"
        '
        'T_nBlock
        '
        Me.T_nBlock.AcceptsReturn = True
        Me.T_nBlock.BackColor = System.Drawing.SystemColors.Window
        Me.T_nBlock.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_nBlock.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_nBlock.Location = New System.Drawing.Point(130, 100)
        Me.T_nBlock.MaxLength = 0
        Me.T_nBlock.Name = "T_nBlock"
        Me.T_nBlock.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_nBlock.Size = New System.Drawing.Size(128, 26)
        Me.T_nBlock.TabIndex = 15
        Me.T_nBlock.Text = "8"
        '
        'T_SystemCode
        '
        Me.T_SystemCode.AcceptsReturn = True
        Me.T_SystemCode.BackColor = System.Drawing.SystemColors.Window
        Me.T_SystemCode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_SystemCode.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.T_SystemCode.Location = New System.Drawing.Point(415, 20)
        Me.T_SystemCode.MaxLength = 0
        Me.T_SystemCode.Name = "T_SystemCode"
        Me.T_SystemCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_SystemCode.Size = New System.Drawing.Size(128, 26)
        Me.T_SystemCode.TabIndex = 4
        Me.T_SystemCode.Text = "95EC4930"
        '
        'T_HotelCode
        '
        Me.T_HotelCode.AcceptsReturn = True
        Me.T_HotelCode.BackColor = System.Drawing.SystemColors.Window
        Me.T_HotelCode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_HotelCode.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.T_HotelCode.Location = New System.Drawing.Point(415, 60)
        Me.T_HotelCode.MaxLength = 0
        Me.T_HotelCode.Name = "T_HotelCode"
        Me.T_HotelCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_HotelCode.Size = New System.Drawing.Size(128, 26)
        Me.T_HotelCode.TabIndex = 3
        Me.T_HotelCode.Text = "AABBCCDD"
        '
        'T_CardPass
        '
        Me.T_CardPass.AcceptsReturn = True
        Me.T_CardPass.BackColor = System.Drawing.SystemColors.Window
        Me.T_CardPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_CardPass.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_CardPass.Location = New System.Drawing.Point(130, 180)
        Me.T_CardPass.MaxLength = 0
        Me.T_CardPass.Name = "T_CardPass"
        Me.T_CardPass.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_CardPass.Size = New System.Drawing.Size(128, 26)
        Me.T_CardPass.TabIndex = 2
        Me.T_CardPass.Text = "33AA9C2693F8"
        '
        'T_Pass
        '
        Me.T_Pass.AcceptsReturn = True
        Me.T_Pass.BackColor = System.Drawing.SystemColors.Window
        Me.T_Pass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_Pass.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_Pass.Location = New System.Drawing.Point(415, 100)
        Me.T_Pass.MaxLength = 0
        Me.T_Pass.Name = "T_Pass"
        Me.T_Pass.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_Pass.Size = New System.Drawing.Size(128, 26)
        Me.T_Pass.TabIndex = 1
        Me.T_Pass.Text = "7BDDBE"
        '
        'Com_ReadMessage
        '
        Me.Com_ReadMessage.BackColor = System.Drawing.SystemColors.Control
        Me.Com_ReadMessage.Cursor = System.Windows.Forms.Cursors.Default
        Me.Com_ReadMessage.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Com_ReadMessage.Location = New System.Drawing.Point(269, 268)
        Me.Com_ReadMessage.Name = "Com_ReadMessage"
        Me.Com_ReadMessage.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Com_ReadMessage.Size = New System.Drawing.Size(126, 62)
        Me.Com_ReadMessage.TabIndex = 0
        Me.Com_ReadMessage.Text = "Read Card"
        Me.Com_ReadMessage.UseVisualStyleBackColor = False
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.SystemColors.Control
        Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label19.Location = New System.Drawing.Point(859, 298)
        Me.Label19.Name = "Label19"
        Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label19.Size = New System.Drawing.Size(96, 18)
        Me.Label19.TabIndex = 48
        Me.Label19.Text = "ValidTimes"
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.Control
        Me.Label18.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label18.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label18.Location = New System.Drawing.Point(956, 144)
        Me.Label18.Name = "Label18"
        Me.Label18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label18.Size = New System.Drawing.Size(38, 18)
        Me.Label18.TabIndex = 41
        Me.Label18.Text = "V16"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.SystemColors.Control
        Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(859, 219)
        Me.Label15.Name = "Label15"
        Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label15.Size = New System.Drawing.Size(101, 18)
        Me.Label15.TabIndex = 40
        Me.Label15.Text = "OpenBolt"
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.Location = New System.Drawing.Point(859, 184)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(100, 18)
        Me.Label13.TabIndex = 39
        Me.Label13.Text = "AlwaysOpen"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(859, 144)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(38, 18)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "V8"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(1046, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(38, 18)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "V24"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(595, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(75, 18)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "STIn"
        '
        'Card_no_
        '
        Me.Card_no_.BackColor = System.Drawing.SystemColors.Control
        Me.Card_no_.Cursor = System.Windows.Forms.Cursors.Default
        Me.Card_no_.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Card_no_.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Card_no_.Location = New System.Drawing.Point(24, 64)
        Me.Card_no_.Name = "Card_no_"
        Me.Card_no_.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Card_no_.Size = New System.Drawing.Size(101, 18)
        Me.Card_no_.TabIndex = 25
        Me.Card_no_.Text = "CardNumber"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(595, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(75, 18)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "SDIn"
        '
        'comport_lbl
        '
        Me.comport_lbl.AutoSize = True
        Me.comport_lbl.BackColor = System.Drawing.SystemColors.Control
        Me.comport_lbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.comport_lbl.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comport_lbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.comport_lbl.Location = New System.Drawing.Point(24, 24)
        Me.comport_lbl.Name = "comport_lbl"
        Me.comport_lbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.comport_lbl.Size = New System.Drawing.Size(97, 18)
        Me.comport_lbl.TabIndex = 22
        Me.comport_lbl.Text = "ComNumber"
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.Control
        Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label17.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label17.Location = New System.Drawing.Point(595, 104)
        Me.Label17.Name = "Label17"
        Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label17.Size = New System.Drawing.Size(75, 18)
        Me.Label17.TabIndex = 20
        Me.Label17.Text = "SDOut"
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.SystemColors.Control
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label16.Location = New System.Drawing.Point(595, 144)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label16.Size = New System.Drawing.Size(75, 18)
        Me.Label16.TabIndex = 19
        Me.Label16.Text = "STOut"
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(24, 144)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(96, 18)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Encrypt"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(24, 104)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(96, 18)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "nBlock"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(859, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(110, 18)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "AddressMode"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(318, 24)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(96, 18)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "SystemCode"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(318, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(96, 18)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "HotelCode"
        '
        'Door_no_lbl
        '
        Me.Door_no_lbl.BackColor = System.Drawing.SystemColors.Control
        Me.Door_no_lbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Door_no_lbl.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Door_no_lbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Door_no_lbl.Location = New System.Drawing.Point(595, 184)
        Me.Door_no_lbl.Name = "Door_no_lbl"
        Me.Door_no_lbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Door_no_lbl.Size = New System.Drawing.Size(82, 18)
        Me.Door_no_lbl.TabIndex = 11
        Me.Door_no_lbl.Text = "LevelPass"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(24, 184)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(96, 18)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "CardPass"
        '
        'O_PASSSS
        '
        Me.O_PASSSS.BackColor = System.Drawing.SystemColors.Control
        Me.O_PASSSS.Cursor = System.Windows.Forms.Cursors.Default
        Me.O_PASSSS.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.O_PASSSS.ForeColor = System.Drawing.SystemColors.ControlText
        Me.O_PASSSS.Location = New System.Drawing.Point(318, 104)
        Me.O_PASSSS.Name = "O_PASSSS"
        Me.O_PASSSS.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.O_PASSSS.Size = New System.Drawing.Size(96, 18)
        Me.O_PASSSS.TabIndex = 9
        Me.O_PASSSS.Text = "PASS"
        '
        'room_address
        '
        Me.room_address.BackColor = System.Drawing.SystemColors.Control
        Me.room_address.Cursor = System.Windows.Forms.Cursors.Default
        Me.room_address.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.room_address.ForeColor = System.Drawing.SystemColors.ControlText
        Me.room_address.Location = New System.Drawing.Point(318, 144)
        Me.room_address.Name = "room_address"
        Me.room_address.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.room_address.Size = New System.Drawing.Size(96, 18)
        Me.room_address.TabIndex = 8
        Me.room_address.Text = "Address"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(859, 64)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(96, 18)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "AddressQty"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(859, 104)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(96, 18)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "TimeMode"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.SystemColors.Control
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(595, 219)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(85, 18)
        Me.Label14.TabIndex = 5
        Me.Label14.Text = "PassMode"
        '
        'T_AlwaysOpen
        '
        Me.T_AlwaysOpen.AcceptsReturn = True
        Me.T_AlwaysOpen.BackColor = System.Drawing.SystemColors.Window
        Me.T_AlwaysOpen.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.T_AlwaysOpen.ForeColor = System.Drawing.SystemColors.WindowText
        Me.T_AlwaysOpen.Location = New System.Drawing.Point(978, 180)
        Me.T_AlwaysOpen.MaxLength = 0
        Me.T_AlwaysOpen.Name = "T_AlwaysOpen"
        Me.T_AlwaysOpen.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.T_AlwaysOpen.Size = New System.Drawing.Size(139, 26)
        Me.T_AlwaysOpen.TabIndex = 53
        Me.T_AlwaysOpen.Text = "0"
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1148, 362)
        Me.Controls.Add(Me.T_AlwaysOpen)
        Me.Controls.Add(Me.Command1)
        Me.Controls.Add(Me.Com_GuestCard)
        Me.Controls.Add(Me.T_ValidTimes)
        Me.Controls.Add(Me.Check_TerminateOld)
        Me.Controls.Add(Me.T_V16)
        Me.Controls.Add(Me.T_OpenBolt)
        Me.Controls.Add(Me.T_V8)
        Me.Controls.Add(Me.T_V24)
        Me.Controls.Add(Me.T_STIN)
        Me.Controls.Add(Me.T_SDIN)
        Me.Controls.Add(Me.T_PassMode)
        Me.Controls.Add(Me.T_TimeMode)
        Me.Controls.Add(Me.T_AddressQty)
        Me.Controls.Add(Me.T_LevelPass)
        Me.Controls.Add(Me.T_AddressMode)
        Me.Controls.Add(Me.T_STOUT)
        Me.Controls.Add(Me.T_SDOUT)
        Me.Controls.Add(Me.T_Address)
        Me.Controls.Add(Me.T_CardNo)
        Me.Controls.Add(Me.T_Com)
        Me.Controls.Add(Me.T_Encrypt)
        Me.Controls.Add(Me.T_nBlock)
        Me.Controls.Add(Me.T_SystemCode)
        Me.Controls.Add(Me.T_HotelCode)
        Me.Controls.Add(Me.T_CardPass)
        Me.Controls.Add(Me.T_Pass)
        Me.Controls.Add(Me.Com_ReadMessage)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Card_no_)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.comport_lbl)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Door_no_lbl)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.O_PASSSS)
        Me.Controls.Add(Me.room_address)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label14)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 30)
        Me.Name = "FormMain"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Guest Card VB.Net DEMO-V30"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents T_AlwaysOpen As TextBox
#End Region
End Class